const pages = document.querySelectorAll(".page");
const menuButtons = document.querySelectorAll(".menu button");

let invoices = JSON.parse(localStorage.getItem("billoraInvoices") || "[]");
let customers = JSON.parse(localStorage.getItem("billoraCustomers") || "[]");
let invoiceCounter = Number(localStorage.getItem("billoraInvoiceCounter") || "0");

const money = (value) => {
    const symbol = document.getElementById("currency")?.value || "₦";
    return symbol + Number(value || 0).toLocaleString("en-NG",{minimumFractionDigits:2,maximumFractionDigits:2});
};

function showPage(index){
    pages.forEach((p,i)=>p.classList.toggle("active",i===index));
    menuButtons.forEach((b,i)=>{
        b.style.background = i===index ? "linear-gradient(135deg,#2563eb,#0891b2)" : "white";
        b.style.color = i===index ? "white" : "#1e3a8a";
    });
}
menuButtons.forEach((b,i)=>b.addEventListener("click",()=>showPage(i)));

document.getElementById("quickInvoice").onclick=()=>{showPage(1); newInvoice();};
document.getElementById("quickCustomer").onclick=()=>showPage(2);

function nextInvoiceNumber(){
    invoiceCounter++;
    localStorage.setItem("billoraInvoiceCounter",invoiceCounter);
    return "INV-" + String(invoiceCounter).padStart(4,"0");
}

function addItem(name="",qty=1,price=0){
    const container=document.getElementById("itemsContainer");
    const n=container.querySelectorAll(".item-box").length+1;
    const box=document.createElement("div");
    box.className="item-box";
    box.innerHTML=`
        <div class="item-number">Item ${n}</div>
        <div class="form-group">
            <label>Product / Service</label>
            <input type="text" class="product-name" placeholder="Enter item name" value="${escapeHtml(name)}">
        </div>
        <div class="two-fields">
            <div class="form-group">
                <label>Quantity</label>
                <input type="number" class="product-quantity" value="${qty}" min="1">
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="number" class="product-price" placeholder="Enter price" value="${price}" min="0">
            </div>
        </div>
        <div class="item-total-box"><span>Item Total</span><strong class="item-total">${money(qty*price)}</strong></div>
        <button type="button" class="btn danger-btn remove-item">🗑️ Remove Item</button>
    `;
    container.appendChild(box);
    box.querySelectorAll("input").forEach(i=>i.addEventListener("input",calculate));
    box.querySelector(".remove-item").onclick=()=>{box.remove();renumber();calculate();};
    calculate();
}

function escapeHtml(v){
    return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}
function renumber(){
    document.querySelectorAll("#itemsContainer .item-box").forEach((box,i)=>box.querySelector(".item-number").textContent="Item "+(i+1));
}

function calculate(){
    let subtotal=0;
    document.querySelectorAll("#itemsContainer .item-box").forEach(box=>{
        const q=Number(box.querySelector(".product-quantity").value)||0;
        const p=Number(box.querySelector(".product-price").value)||0;
        const total=q*p;
        subtotal+=total;
        box.querySelector(".item-total").textContent=money(total);
    });
    const discount=Math.max(0,Number(document.getElementById("invoiceDiscount").value)||0);
    const total=Math.max(0,subtotal-discount);
    const paid=Math.max(0,Number(document.getElementById("invoiceAmountPaid").value)||0);
    const balance=Math.max(0,total-paid);
    const status=document.getElementById("summaryStatus");
    document.getElementById("orderTotalAmount").textContent=money(subtotal);
    document.getElementById("summarySubtotal").textContent=money(subtotal);
    document.getElementById("summaryDiscount").textContent=money(discount);
    document.getElementById("summaryTotal").textContent=money(total);
    document.getElementById("summaryPaid").textContent=money(Math.min(paid,total));
    document.getElementById("summaryBalance").textContent=money(balance);
    status.className="status "+(paid<=0?"unpaid":balance<=0?"paid":"partial");
    status.textContent=paid<=0?"Unpaid":balance<=0?"Paid":"Partially Paid";
}

function clearInvoice(){
    document.getElementById("customerName").value="";
    document.getElementById("customerPhone").value="";
    document.getElementById("invoiceNumber").value=nextInvoiceNumber();
    document.getElementById("invoiceDate").value=new Date().toISOString().slice(0,10);
    document.getElementById("invoiceDiscount").value=0;
    document.getElementById("invoiceAmountPaid").value=0;
    document.getElementById("currency").value="₦";
    document.getElementById("itemsContainer").innerHTML="";
    addItem();
    calculate();
}
function newInvoice(){clearInvoice();showPage(1);}

document.getElementById("addAnotherItem").onclick=()=>addItem();
document.getElementById("invoiceDiscount").addEventListener("input",calculate);
document.getElementById("invoiceAmountPaid").addEventListener("input",calculate);
document.getElementById("currency").addEventListener("change",calculate);

document.getElementById("saveInvoice").onclick=()=>{
    const customerName=document.getElementById("customerName").value.trim();
    if(!customerName){alert("Please enter the customer name.");return;}
    let subtotal=0,items=[];
    document.querySelectorAll("#itemsContainer .item-box").forEach(box=>{
        const name=box.querySelector(".product-name").value.trim();
        const quantity=Number(box.querySelector(".product-quantity").value)||0;
        const price=Number(box.querySelector(".product-price").value)||0;
        if(name) items.push({name,quantity,price,total:quantity*price});
        subtotal+=quantity*price;
    });
    const discount=Math.max(0,Number(document.getElementById("invoiceDiscount").value)||0);
    const total=Math.max(0,subtotal-discount);
    const paid=Math.min(Math.max(0,Number(document.getElementById("invoiceAmountPaid").value)||0),total);
    const balance=Math.max(0,total-paid);
    const invoice={
        id:Date.now(),number:document.getElementById("invoiceNumber").value,
        date:document.getElementById("invoiceDate").value,
        customer:customerName,phone:document.getElementById("customerPhone").value,
        items,subtotal,discount,total,paid,balance,
        method:document.getElementById("invoicePaymentMethod").value
    };
    invoices.unshift(invoice);
    localStorage.setItem("billoraInvoices",JSON.stringify(invoices));
    renderInvoices();renderCustomers();updateDashboard();
    alert("Invoice saved successfully.");
};

document.getElementById("printInvoice").onclick=()=>window.print();
document.getElementById("newInvoice").onclick=newInvoice;

function renderInvoices(){
    const box=document.getElementById("savedInvoices");
    if(!invoices.length){box.innerHTML='<div class="empty">No saved invoices yet.</div>';return;}
    box.innerHTML=invoices.map(inv=>`
        <div class="invoice-card">
            <strong>${escapeHtml(inv.number)}</strong><br>
            ${escapeHtml(inv.customer)}<br>
            Total: ${money(inv.total)}<br>
            Paid: ${money(inv.paid)}<br>
            Balance: ${money(inv.balance)}
            <br><span class="status ${inv.balance<=0?"paid":inv.paid>0?"partial":"unpaid"}">${inv.balance<=0?"Paid":inv.paid>0?"Partially Paid":"Unpaid"}</span>
        </div>`).join("");
}

document.getElementById("saveCustomer").onclick=()=>{
    const name=document.getElementById("newCustomerName").value.trim();
    const phone=document.getElementById("newCustomerPhone").value.trim();
    if(!name){alert("Please enter customer name.");return;}
    customers.push({id:Date.now(),name,phone});
    localStorage.setItem("billoraCustomers",JSON.stringify(customers));
    document.getElementById("newCustomerName").value="";
    document.getElementById("newCustomerPhone").value="";
    renderCustomers();updateDashboard();
    alert("Customer saved successfully.");
};

function renderCustomers(filter=""){
    const list=document.getElementById("customerList");
    const data=customers.filter(c=>c.name.toLowerCase().includes(filter.toLowerCase())||c.phone.includes(filter));
    if(!data.length){list.innerHTML='<div class="box pink-box"><div class="empty">No customers found.</div></div>';return;}
    list.innerHTML=data.map(c=>{
        const ci=invoices.filter(i=>i.customer.toLowerCase()===c.name.toLowerCase());
        const total=ci.reduce((s,i)=>s+i.total,0),paid=ci.reduce((s,i)=>s+i.paid,0),balance=ci.reduce((s,i)=>s+i.balance,0);
        return `<div class="customer-card"><h3>👤 ${escapeHtml(c.name)}</h3><p>📞 ${escapeHtml(c.phone||"No phone")}</p><br>
        <p>Total Invoices: <strong>${ci.length}</strong></p><p>Total Invoice: <strong>${money(total)}</strong></p><p>Total Paid: <strong>${money(paid)}</strong></p><p>Remaining Balance: <strong>${money(balance)}</strong></p>
        <button class="btn danger-btn" onclick="removeCustomer(${c.id})">🗑️ Remove Customer</button></div>`;
    }).join("");
}
window.removeCustomer=(id)=>{
    if(!confirm("Remove this customer?"))return;
    customers=customers.filter(c=>c.id!==id);
    localStorage.setItem("billoraCustomers",JSON.stringify(customers));
    renderCustomers();updateDashboard();
};
document.getElementById("customerSearch").addEventListener("input",e=>renderCustomers(e.target.value));

function updateDashboard(){
    const total=invoices.reduce((s,i)=>s+i.total,0),paid=invoices.reduce((s,i)=>s+i.paid,0),bal=invoices.reduce((s,i)=>s+i.balance,0);
    document.getElementById("dashInvoice").textContent=money(total);
    document.getElementById("dashPaid").textContent=money(paid);
    document.getElementById("dashRemaining").textContent=money(bal);
    document.getElementById("dashCustomers").textContent=customers.length;
    document.getElementById("reportInvoice").textContent=money(total);
    document.getElementById("reportPaid").textContent=money(paid);
    document.getElementById("reportOutstanding").textContent=money(bal);
    document.getElementById("reportCount").textContent=invoices.length;
}

document.getElementById("saveSettings").onclick=()=>{
    const settings={
        name:document.getElementById("businessName").value,
        phone:document.getElementById("businessPhone").value,
        email:document.getElementById("businessEmail").value,
        address:document.getElementById("businessAddress").value
    };
    localStorage.setItem("billoraSettings",JSON.stringify(settings));
    alert("Business information saved.");
};

function loadSettings(){
    const s=JSON.parse(localStorage.getItem("billoraSettings")||"{}");
    ["businessName","businessPhone","businessEmail","businessAddress"].forEach((id,i)=>{
        document.getElementById(id).value=Object.values(s)[i]||"";
    });
}

document.getElementById("invoiceDate").value=new Date().toISOString().slice(0,10);
document.getElementById("invoiceNumber").value=nextInvoiceNumber();
addItem();
renderInvoices();
renderCustomers();
updateDashboard();
loadSettings();
showPage(0);
